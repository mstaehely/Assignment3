import java.awt.*;

/**
 * Constructs "cross" shaped objects.
 * 
 * @author Matthew Staehely
 * @version CSC 143 Winter 15
 */
public class Cross extends AbstractShape implements Shape
{
    private int height; //maximum height of cross
    
    /**
     * Constructor of class Cross.
     * 
     * @param corner the upper left corner of the bounding box.
     * @param height the maximum height of the object.
     * 
     * @throws IllegalArgumentException if either coordinate of the corner is less 
     * than 0 or the height is zero. Also thrown if the height is not divisible by 5.
     */
    public Cross(Point corner, int height)
    {
        if(height == 0 || height %5 > 0 || corner.getX() < 0 || corner.getY() < 0)
        throw new IllegalArgumentException();
        this.height = height;
        setColor(Color.BLACK);
        setSelected(false);
        setLocation(new Point((int)corner.getX(), (int)corner.getY()));
    }
    
    /**
     * Tests to see if a point is located on the Shape.
     * 
     * @param x the x-coordinate of the point to be tested.
     * @param y the y-coordinate of the point to be tested.
     * 
     * @return true if the given x,y coordinates are on the Shape.
     * @throws IllegalArgumentException if either test coordinate is less than zero.
     */
    public boolean isOn(int x, int y)
    {
        if(x < 0 || y < 0) throw new IllegalArgumentException();
        return((x > location.getX() + this.height*2/5 &&
                x < location.getX() + this.height*4/5 &&
                y > location.getY() && y < location.getY() + this.height) ||
               (x > location.getX() && x < location.getX() + this.height &&
                y > location.getY() + this.height*2/5 &&
                y < location.getY() + this.height*4/5));
    }
    
    public String toString(){
        String s = super.toString();
        s += "\nHeight: " + this.height + "\n";
        return s;
    }
}
import java.awt.*;

/**
 * Constructs circular Shape objects
 * 
 * @author Matthew Staehely
 * @version CSC 143 Winter 15
 */
public class Circle extends AbstractShape implements Shape
{
    Point center; // center of the Circle. Useful for isOn method of this class.
    int radius; // radius of Circle. Useful for isOn method of this class.   
    /**
     * Constructor of class Circle.
     * 
     * @param center the point at which the center of the circle is located.
     * @param radius the radius of the circle.
     * 
     * @throws IllegalArgumentExcpetion if the radius is 0 or less, or either 
     * coordinate of the center is less than 0.
     */
    public Circle(Point center, int radius)
    {
       if(center.getX() < 0 || center.getY() < 0 || radius <= 0)
       throw new IllegalArgumentException();
       this.center = new Point((int)center.getX(), (int)center.getY());
       this.radius = radius;
       setColor(Color.BLACK);
       setSelected(false);
       setLocation(new Point((int)center.getX()-radius, (int)center.getY()-radius));
    }
    
    /**
     * Tests to see if a point is located on the Shape.
     * 
     * @param x the x-coordinate of the point to be tested.
     * @param y the y-coordinate of the point to be tested.
     * 
     * @throws IllegalArgumentException if either coordinate is less than zero.
     * @return true if the given x,y coordinates are on the Shape.
     */
    public boolean isOn(int x, int y)
    {
        if(x < 0 || y < 0) throw new IllegalArgumentException();
        Point test = new Point(x, y); // useful for distance method of Point class.
        return(test.distance(this.center) <= radius);
    }
    
    /**
     * Provides a String representation of the Shape. Intended for testing purposes.
     * 
     * @return String representation of this Shape.
     */
    public String toString(){
        String s = super.toString();
        s += "\nRadius: " + this.radius + "\nCenter: " + this.center + "\n";
        return s;
    }
}
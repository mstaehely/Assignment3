/**
 * Provides a template to construct views for a Model-View-Controller user interface.
 * 
 * @author Matthew Staehely
 * @version CSC 143 Winter 15
 */
public interface ShapeListener {
    public void shapeChanged();
}